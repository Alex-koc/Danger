<?php
$pdo = new PDO('mysql:host=localhost;dbname=magazin', 'root', '');